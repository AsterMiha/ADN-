import 'package:flutter/material.dart';

class Analize extends StatefulWidget {
  @override
  _AnalizeState createState() => _AnalizeState();
 
}

class _AnalizeState extends State<Analize> {
   Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Analize"),
      ),
    );
  }
}